export interface Blog {
    "__v": number;
    "_id": string;
    guid: string;
    image: string;
    isoDate: string;
    pubDate: string;
    title: string;
    creator: string;
}
//# sourceMappingURL=blog.types.d.ts.map